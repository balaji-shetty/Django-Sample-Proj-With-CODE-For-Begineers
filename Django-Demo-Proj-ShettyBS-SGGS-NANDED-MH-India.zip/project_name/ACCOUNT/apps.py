from django.apps import AppConfig


class AccountConfig(AppConfig):
    name = 'ACCOUNT'
