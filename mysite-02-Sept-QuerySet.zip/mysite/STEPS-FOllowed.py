(CORONA) (base) balaji@balaji-Latitude-3400:~/NED-Collector$ django-admin startproject mysite
(CORONA) (base) balaji@balaji-Latitude-3400:~/NED-Collector$ cd mysite/
(CORONA) (base) balaji@balaji-Latitude-3400:~/NED-Collector/mysite$ django-admin startapp blog
(CORONA) (base) balaji@balaji-Latitude-3400:~/NED-Collector/mysite$ django-admin startapp reviews
(CORONA) (base) balaji@balaji-Latitude-3400:~/NED-Collector/mysite$ ls
blog  manage.py  mysite  reviews
